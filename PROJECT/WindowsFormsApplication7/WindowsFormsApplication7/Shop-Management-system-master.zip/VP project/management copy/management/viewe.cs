﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq.Mapping;
using management.Classes;

namespace management
{
    public partial class viewe : Form
    {
        public viewe()
        {
            InitializeComponent();
        }
        DataContext dc = new DataContext("Data Source=DESKTOP-4F5AJD6;Initial Catalog=UMS;Integrated Security=True");
        private void viewe_Load(object sender, EventArgs e)
        {
            Table<employerec> s1 = dc.GetTable<employerec>();
            DataTable dt =new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("NAME", typeof(string));
            dt.Columns.Add("Address", typeof(string));
            dt.Columns.Add("Contact", typeof(string));
            dt.Columns.Add("Gender", typeof(string));
            dt.Columns.Add("Salary", typeof(int));
            dt.Columns.Add("Department", typeof(string));
            dt.Columns.Add("Age", typeof(int));
            dt.Columns.Add("CNIC", typeof(string));
            var qurey = from k in s1
                        select k;
            foreach (var s in qurey)
            {
                dt.Rows.Add(s._id, s._name, s._address, s._phone, s._gender, s._salary, s._department, s._age, s._CNIC);
            }
            dataGridView1.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Table<employerec> s1 =dc.GetTable<employerec>();
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            var qurey = from k in s1
                        where k._id == id
                        select k;
            foreach (var s in qurey)
            {
                s1.DeleteOnSubmit(s);
            }
            dc.SubmitChanges();
            MessageBox.Show("Data Deleted");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Table<employerec> s1 = dc.GetTable<employerec>();
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Address", typeof(string));
            dt.Columns.Add("Contact", typeof(string));
            dt.Columns.Add("Gender", typeof(string));
            dt.Columns.Add("Salary", typeof(int));
            dt.Columns.Add("Department", typeof(string));
            dt.Columns.Add("Age", typeof(int));
            dt.Columns.Add("CNIC", typeof(string));
            var qurey = from k in s1
                        where k._name == textBox1.Text
                        select k;
            foreach(employerec s in qurey)
            {
                dt.Rows.Add(s._id,s._name,s._address,s._phone,s._gender, s._salary, s._department, s._age, s._CNIC);


            }
            dataGridView1.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {   
            int id =Convert.ToInt32 (dataGridView1.SelectedRows[0].Cells[0].Value);
            updatee v = new updatee();
            v.datashow(id);
            v.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
  
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
  
        }
    }
}
