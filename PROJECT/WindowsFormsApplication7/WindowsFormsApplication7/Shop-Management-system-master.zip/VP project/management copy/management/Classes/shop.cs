﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data.Linq.Mapping;
namespace management.Classes
{
    [Table(Name = "shop_system")]
    class shop
    {
        int ID;
        [Column(Name = "ID", IsPrimaryKey = true)]
        public int _ID
        {
            get { return ID; }
            set { ID = value; }
        }
        string NAME;
        [Column(Name = "ProductName")]
        public string _NAME
        {
            get { return NAME; }
            set { NAME = value; }
        }
        int Price;
        [Column(Name = "ProductPrice")]
        public int _Price
        {
            get { return Price; }
            set { Price = value; }
        }
        int quenty;
        [Column(Name ="ProductQuenty")]
        public int _Quenty
        {
            get { return quenty; }
            set {quenty  = value; }
        }
        DateTime Date;
        [Column(Name = "ProductDate")]
        public DateTime _Date
        {
            get { return Date; }
            set { Date = value; }
        }
    } 
}
