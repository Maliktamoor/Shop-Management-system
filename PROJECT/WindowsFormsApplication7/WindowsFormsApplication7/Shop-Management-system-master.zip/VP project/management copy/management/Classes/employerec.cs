﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
using System.Data.Linq.Mapping;
namespace management
{

 [Table(Name = "Emp_table")]
    class employerec
    {
        int id;
     [Column(Name="Emp_id" , IsPrimaryKey=true)]
        public int _id
        {
            get { return id; }
            set { id = value; } 
        }
        string name;
     [Column(Name="Emp_name")]
        public string _name
        {
            get { return name; }
            set { name = value; }
        }
        string address;
     [Column(Name = "Emp_address")]
        public string _address
        {
            get { return address; }
            set { address = value; }
        }
     string phone;
     [Column(Name = "Emp_phone")]
     public string _phone
     {
         get { return phone; }
         set { phone = value; }
     }
      String gender;
      [Column(Name = "Emp_gender")]
        public string  _gender
        {
            get { return gender; }
            set { gender = value; }
        }
        int salary;
      [Column(Name = "Emp_salary")]
        public int  _salary    
        {
            get { return salary; }
            set { salary = value; }
        }
        string department;
      [Column(Name = "Emp_department")]
        public string _department
        {
            get { return department;}
            set {department = value; }
        }
        string age;
      [Column(Name = "Emp_Age")]
        public string _age
        {
            get { return age; }
            set {age = value; }
        }
      string CNIC;
      [Column(Name = "Emp_CNIC")]
      public string _CNIC
      {
          get { return CNIC; }
          set { CNIC = value; }
      }


    }
}
